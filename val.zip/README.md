# Simple Vulnerability Scanner

A beginner-friendly Python script that scans a website for common security issues.

---

## What It Does

| Step | Check |
|------|-------|
| Step 1 | Scans 9 common ports (FTP, SSH, HTTP, MySQL, etc.) |
| Step 2 | Checks for missing security headers & version leaks |
| Step 3 | Probes sensitive paths like `/.env`, `/admin`, `/.git` |
| Step 4 | Saves a full report to `vulnerability_report.txt` |

---

## Requirements

- Python 3.x (already on most computers)
- `requests` library

---

## How to Set Up (One Time Only)

### Step 1 — Install Python
Download from: https://www.python.org/downloads/
> ✅ Tick **"Add Python to PATH"** during install

### Step 2 — Install the requests library
Open a terminal (or VS Code terminal) and run:
```
pip install requests
```

---

## How to Run in VS Code

### Step 1 — Open the folder in VS Code
```
File → Open Folder → select the folder with vuln_scanner.py
```

### Step 2 — Open the terminal inside VS Code
```
Terminal → New Terminal   (or press Ctrl + `)
```

### Step 3 — Run the script
```
python vuln_scanner.py
```

### Step 4 — Enter your target
```
Your target: http://testphp.vulnweb.com
```
> Press Enter with no input to scan your own localhost (127.0.0.1)

---

## Free Practice Targets (Safe & Legal)

| URL | Description |
|-----|-------------|
| `http://testphp.vulnweb.com` | Intentionally vulnerable PHP site by Acunetix |
| `http://127.0.0.1` | Your own localhost |
| Any server **you own** | Always allowed |

> ⚠️ **Only scan systems you own or have permission to test.**
> Scanning others without permission is illegal.

---

## Output Example

```
==================================================
  STEP 1: PORT SCAN
==================================================
  [  OK  ] Port 21 closed → FTP
  [ RISK ] Port 80 OPEN   → HTTP
  [ RISK ] Port 23 OPEN   → Telnet  ⚠ RISKY

==================================================
  STEP 2: SECURITY HEADERS CHECK
==================================================
  [ RISK ] Header MISSING → X-Frame-Options
  [ RISK ] Site uses HTTP instead of HTTPS

==================================================
  STEP 4: GENERATING REPORT
==================================================
  Report saved → vulnerability_report.txt
  Total issues found: 5
  Result: MEDIUM RISK
```

---

## Files in This Project

```
📁 Your Folder
├── vuln_scanner.py          ← Main script (run this)
├── README.md                ← This guide
└── vulnerability_report.txt ← Created after each scan
```

---

## Common Errors & Fixes

| Error | Fix |
|-------|-----|
| `python not found` | Install Python and tick "Add to PATH" |
| `pip not found` | Use `python -m pip install requests` instead |
| `ModuleNotFoundError: requests` | Run `pip install requests` |
| `Connection refused` | Target is offline or blocking scans — try another URL |

---

## What You Learn From This Project

- How port scanning works
- What HTTP security headers are and why they matter
- How attackers look for exposed files like `.env` and `.git`
- How to read and generate a basic vulnerability report
- Basics of Python networking with `socket` and `requests`
